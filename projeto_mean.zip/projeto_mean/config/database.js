module.exports = {
	database: 'mongodb://localhost:27017/asw17',
	secret  : 'buv2NS$O^dxh5&lv0EM*Bg5WA!tK&3'
}