"use strict"
$(window).on('load', function(){
	$('#table-GBP').DataTable({
    	paging: false,
    	searching: false,
    	ordering:  false
	});
});