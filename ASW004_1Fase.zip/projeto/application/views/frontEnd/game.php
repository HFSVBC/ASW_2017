<?php
defined('BASEPATH') OR exit('No direct script access allowed');?>

	<div class="side-bar">
		<div class="btn-group-vertical" role="group" aria-label="...">
			<button type="button" class="btn btn-default">1</button>
  			<button type="button" class="btn">2</button>
  			<button type="button" class="btn">3</button>
		</div>

		<button class="btn btn-primary" id="chat" type="button">
  			Chat <span class="badge">4</span>
		</button>
	</div>

	<div id="gameBody">

			<div id="U1"> U1</div>
			<div id="U2"> U1</div>
			<div id="U3"> U1</div>
			<div id="U4"> U1</div>
			<div id="U5"> U1</div>
			<div id="U6"> U1</div>
			<div id="U7"> U1</div>
			<div id="U8"> U1</div>

	</div>