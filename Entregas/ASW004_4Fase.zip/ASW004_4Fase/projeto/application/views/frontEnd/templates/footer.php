<?php
defined('BASEPATH') OR exit('No direct script access allowed');?>
	<footer id="footerAndCopyright">
		<p id="FC-copyright">&copy; Copyright Poker Online, 2017-<?php date_default_timezone_set("Europe/Lisbon"); echo date("Y");?>. Todos os direitos reservados.</p>
	</footer>  
</body>
</html>