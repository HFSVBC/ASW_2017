<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

   class Nusoap_lib {
      function Nusoap_lib() {
         require_once('lib/nusoap.php');
      }
   }
?>